```javascript
`settings.jar`是最开始备份的那个,
    接下来更新的备份将会使用zip压缩包覆盖
```

